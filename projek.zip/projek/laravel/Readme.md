Berikut adalah **kode lengkap** dari awal untuk **web jual beli** dengan **role**: **Penjual** dan **Pembeli**, menggunakan **Laravel**, **Filament**, dan **MariaDB**.  

---

## **1. Install Laravel & Filament**  
Jalankan perintah berikut untuk menginstal Laravel dan Filament:  
```bash
composer create-project laravel/laravel jualbeli
cd jualbeli
composer require filament/filament
php artisan make:auth
php artisan migrate
```

Tambahkan **Filament Admin**:  
```bash
php artisan make:filament-user
```
**Buat akun admin** agar bisa masuk ke Filament:  
```bash
php artisan filament:admin
```

---

## **2. Buat Migration (Database Schema)**  
Jalankan perintah untuk membuat migration:  
```bash
php artisan make:migration add_role_to_users_table --table=users
php artisan make:migration create_products_table
php artisan make:migration create_orders_table
```

### **Modify Migration Users (Tambahkan Kolom Role)**
Edit file `database/migrations/xxxx_xx_xx_xxxxxx_add_role_to_users_table.php`:

```php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['penjual', 'pembeli'])->after('password')->default('pembeli');
        });
    }

    public function down() {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('role');
        });
    }
};
```

### **Migration Produk**
Edit `database/migrations/xxxx_xx_xx_xxxxxx_create_products_table.php`:

```php
return new class extends Migration {
    public function up() {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade'); // Penjual
            $table->string('name');
            $table->text('description');
            $table->decimal('price', 10, 2);
            $table->integer('stock');
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('products');
    }
};
```

### **Migration Orders**
Edit `database/migrations/xxxx_xx_xx_xxxxxx_create_orders_table.php`:

```php
return new class extends Migration {
    public function up() {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('buyer_id')->constrained('users')->onDelete('cascade'); // Pembeli
            $table->foreignId('product_id')->constrained('products')->onDelete('cascade');
            $table->integer('quantity');
            $table->decimal('total_price', 10, 2);
            $table->timestamps();
        });
    }

    public function down() {
        Schema::dropIfExists('orders');
    }
};
```

Jalankan migrasi:  
```bash
php artisan migrate
```

---

## **3. Model Laravel**
Buat model untuk **Product** dan **Order**:  
```bash
php artisan make:model Product
php artisan make:model Order
```

### **Modifikasi Model User**
Edit `app/Models/User.php`:

```php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;

class User extends Authenticatable {
    use HasFactory, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'role'];

    protected $hidden = ['password'];

    public function products(): HasMany {
        return $this->hasMany(Product::class);
    }

    public function orders(): HasMany {
        return $this->hasMany(Order::class, 'buyer_id');
    }
}
```

### **Model Product**
Edit `app/Models/Product.php`:

```php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Product extends Model {
    use HasFactory;

    protected $fillable = ['user_id', 'name', 'description', 'price', 'stock'];

    public function user(): BelongsTo {
        return $this->belongsTo(User::class);
    }
}
```

### **Model Order**
Edit `app/Models/Order.php`:

```php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Order extends Model {
    use HasFactory;

    protected $fillable = ['buyer_id', 'product_id', 'quantity', 'total_price'];

    public function buyer(): BelongsTo {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function product(): BelongsTo {
        return $this->belongsTo(Product::class);
    }
}
```

---

## **4. Seeder**
Buat seeder untuk mengisi database:  
```bash
php artisan make:seeder UserSeeder
php artisan make:seeder ProductSeeder
php artisan make:seeder OrderSeeder
```

### **Seeder User**
Edit `database/seeders/UserSeeder.php`:

```php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder {
    public function run() {
        User::create([
            'name' => 'Penjual 1',
            'email' => 'penjual@example.com',
            'password' => Hash::make('password'),
            'role' => 'penjual'
        ]);

        User::create([
            'name' => 'Pembeli 1',
            'email' => 'pembeli@example.com',
            'password' => Hash::make('password'),
            'role' => 'pembeli'
        ]);
    }
}
```

### **Seeder Produk**
Edit `database/seeders/ProductSeeder.php`:

```php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\User;

class ProductSeeder extends Seeder {
    public function run() {
        $penjual = User::where('role', 'penjual')->first();

        Product::create([
            'user_id' => $penjual->id,
            'name' => 'Produk A',
            'description' => 'Deskripsi Produk A',
            'price' => 100000,
            'stock' => 10
        ]);
    }
}
```

### **Seeder Order**
Edit `database/seeders/OrderSeeder.php`:

```php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;

class OrderSeeder extends Seeder {
    public function run() {
        $pembeli = User::where('role', 'pembeli')->first();
        $product = Product::first();

        Order::create([
            'buyer_id' => $pembeli->id,
            'product_id' => $product->id,
            'quantity' => 2,
            'total_price' => 200000
        ]);
    }
}
```

Jalankan perintah untuk mengisi database:  
```bash
php artisan db:seed --class=UserSeeder
php artisan db:seed --class=ProductSeeder
php artisan db:seed --class=OrderSeeder
```

---

## **Kesimpulan**
✔ **Laravel & Filament siap** dengan role **Penjual & Pembeli**  
✔ **Database sudah diatur** dengan tabel **users, products, dan orders**  
✔ **Seeder mengisi data awal**  

Sekarang web jual beli sudah bisa berjalan! 🚀